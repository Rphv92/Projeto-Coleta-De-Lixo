package br.com.fiap.coletas.dto;

import br.com.fiap.coletas.model.Coletas;

import java.time.LocalDate;
import java.time.LocalTime;

public record ColetasExibicaoDto(
        Long id,
        String cep,
        LocalDate dataColeta,
        LocalTime horaInicio,
        LocalTime horaTermino
) {

    public ColetasExibicaoDto (Coletas coletas){
        this(coletas.getId(),
                coletas.getCep(),
                coletas.getDataColeta(),
                coletas.getHoraInicio(),
                coletas.getHoraTermino());
    }



}
