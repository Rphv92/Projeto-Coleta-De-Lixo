package br.com.fiap.coletas.model;

import jakarta.persistence.*;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;


@Entity
@Table (name = "tbl_coletas")

public class Coletas  {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE,generator = "TBL_COLETAS_SEQ")
    @SequenceGenerator(name = "TBL_COLETAS_SEQ", sequenceName = "TBL_COLETAS_SEQ", allocationSize = 1)
    private Long id;
    private String cep;
    @Column(name = "data_coleta")
    private LocalDate dataColeta;
    @Column(name = "hora_inicio")
    private LocalTime horaInicio;
    @Column(name = "hora_termino")
    private LocalTime horaTermino;


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getCep() {
        return cep;
    }

    public void setCep(String cep) {
        this.cep = cep;
    }

    public LocalDate getDataColeta() {
        return dataColeta;
    }

    public void setDataColeta(LocalDate dataColeta) {
        this.dataColeta = dataColeta;
    }

    public LocalTime getHoraInicio() {
        return horaInicio;
    }

    public void setHoraInicio(LocalTime horaInicio) {
        this.horaInicio = horaInicio;
    }

    public LocalTime getHoraTermino() {
        return horaTermino;
    }

    public void setHoraTermino(LocalTime horaTermino) {
        this.horaTermino = horaTermino;
    }


    @Override
    public String toString() {
        return "Coletas{" +
                "id=" + id +
                ", cep='" + cep + '\'' +
                ", dataColeta=" + dataColeta +
                ", horaInicio=" + horaInicio +
                ", horaTermino=" + horaTermino +
                '}';
    }
}
