package br.com.fiap.coletas.controller.Coleta;


import br.com.fiap.coletas.model.Coletas;
import br.com.fiap.coletas.repository.ColetaRepository;
import br.com.fiap.coletas.service.ColetasService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/api")

public class ColetasController {

    @Autowired
    private ColetasService service;


    @PostMapping ("/gravarcoleta")
    @ResponseStatus(HttpStatus.CREATED)
    public Coletas gravar(@RequestBody Coletas coletas){
        return service.gravar(coletas);
    }

    @GetMapping("/listarcoletas")
    @ResponseStatus(HttpStatus.OK)
    public List<Coletas> listarTodasColetas(){

        return service.listarTodasColetas();
    }

    @DeleteMapping("/deletarcoleta/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void excluir (@PathVariable Long id){
        service.excluirColeta(id);
    }

    @PutMapping("/atualizarcoleta")
    @ResponseStatus(HttpStatus.OK)
    public Coletas atalizar(@RequestBody Coletas coletas){
        return service.atualizarColeta(coletas);

    }


}
