package br.com.fiap.coletas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ColetasApplication {

	public static void main(String[] args) {
		SpringApplication.run(ColetasApplication.class, args);
	}

}
