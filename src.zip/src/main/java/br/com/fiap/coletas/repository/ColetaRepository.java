package br.com.fiap.coletas.repository;

import br.com.fiap.coletas.model.Coletas;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDate;
import java.util.Optional;


public interface ColetaRepository extends JpaRepository<Coletas, Long> {

    public Optional<Coletas> findByCep(String cep);
    public Coletas findByDataColetaBetween(LocalDate dataInicial, LocalDate dataFinal);
}
