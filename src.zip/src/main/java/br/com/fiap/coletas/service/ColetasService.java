package br.com.fiap.coletas.service;


import br.com.fiap.coletas.model.Coletas;
import br.com.fiap.coletas.repository.ColetaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.swing.text.html.Option;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Service
public class ColetasService {

    @Autowired
    private ColetaRepository coletaRepository;

    public Coletas gravar(Coletas coletas){

        return coletaRepository.save(coletas);

    }

    public Coletas buscarPorCep(String cep){

        Optional<Coletas> coletasOptional = coletaRepository.findByCep(cep);

        if(coletasOptional.isPresent()){

            return coletasOptional.get();

        } else {

            throw new RuntimeException("Coleta não encontrada");
        }
    }

    public List<Coletas> listarTodasColetas(){
        return coletaRepository.findAll();
    }

    public void excluirColeta(Long id){

        Optional<Coletas> coletasOptional = coletaRepository.findById(id);

        if (coletasOptional.isPresent()){
            coletaRepository.delete(coletasOptional.get());
        } else {
            throw new RuntimeException("Coleta não encontrada");
        }

    }

    public List<Coletas> mostrarColetasDatadas(LocalDate dataInicial, LocalDate dataFinal){

        return (List<Coletas>) coletaRepository.findByDataColetaBetween(dataInicial, dataFinal);

    }

    public Coletas atualizarColeta (Coletas coletas){

        Optional<Coletas> coletasOptional = coletaRepository.findById(coletas.getId());

        if (coletasOptional.isPresent()){
            return coletaRepository.save(coletas);
        } else {
            throw new RuntimeException("Não foi possível encontrar a coleta!");
        }
    }

}
